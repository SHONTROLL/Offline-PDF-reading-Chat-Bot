Steps to run the project

1 Open the folder in VS Code

2 Run pip install -r requirements to install all the libraries used in the project

3 download ollama

4 run streamlit run streamlit_app.py