from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

MODEL_PATH = "./models/phi-2"

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH, torch_dtype=torch.float16, device_map="auto", local_files_only=True
)

def get_answer(vs, query):
    query_embedding = vs["model"].encode([query])
    D, I = vs["index"].search(query_embedding, k=1)
    context = vs["texts"][I[0][0]]

    prompt = f"""Answer the following question based on the context:\n\nContext:\n{context}\n\nQuestion: {query}\nAnswer:"""

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    outputs = model.generate(**inputs, max_new_tokens=200)
    answer = tokenizer.decode(outputs[0], skip_special_tokens=True)

    return answer.split("Answer:")[-1].strip()
