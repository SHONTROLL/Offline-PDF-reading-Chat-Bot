from sentence_transformers import SentenceTransformer
import faiss
import numpy as np


model = SentenceTransformer("./models/all-MiniLM-L6-v2")

def get_vectorstore(chunks):
    embeddings = model.encode(chunks)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(np.array(embeddings))
    return {"index": index, "texts": chunks, "model": model}
